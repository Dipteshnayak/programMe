import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import CodeEditor from './components/CodeEditor';
import OutputTerminal from './components/OutputTerminal';
import type { OutputLine } from './components/OutputTerminal';
import './App.css';

// Declare standard Pyodide types implicitly
declare global {
  interface Window {
    loadPyodide: any;
  }
}

const DEFAULT_CODE = `# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
print("Try programiz.pro")
print("Hello, World!")
`;

function App() {
  const [code, setCode] = useState<string>(DEFAULT_CODE);
  const [output, setOutput] = useState<OutputLine[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [pyodide, setPyodide] = useState<any>(null);
  const [isLoadingPyodide, setIsLoadingPyodide] = useState(true);

  // Load Pyodide
  useEffect(() => {
    const loadEngine = async () => {
      try {
        if (!window.loadPyodide) {
          // wait logic could go here
          console.warn("Pyodide not found on window immediately");
        }

        const pyodideInstance = await window.loadPyodide({
          stdout: (text: string) => {
            setOutput((prev) => [...prev, { type: 'stdout', content: text }]);
          },
          stderr: (text: string) => {
            setOutput((prev) => [...prev, { type: 'stderr', content: text }]);
          }
        });
        setPyodide(pyodideInstance);
        setIsLoadingPyodide(false);
      } catch (e) {
        console.error("Failed to load Pyodide", e);
        setOutput([{ type: 'stderr', content: "Failed to load Python environment." }]);
      }
    };

    loadEngine();
  }, []);

  const handleRun = async () => {
    if (!pyodide) return;

    setIsRunning(true);
    setOutput([]); // Clear previous output

    try {
      await pyodide.runPythonAsync(code);
    } catch (error: any) {
      setOutput((prev) => [...prev, { type: 'stderr', content: String(error) }]);
    } finally {
      setIsRunning(false);
    }
  };

  const handleClear = () => {
    setOutput([]);
  };

  return (
    <div className="app-container">
      <Sidebar />
      <main className="main-content">
        <Navbar onRun={handleRun} isRunning={isRunning || isLoadingPyodide} />
        <div className="editor-area">
          <div className="editor-pane">
            <CodeEditor code={code} onChange={(val) => setCode(val || '')} />
          </div>
          <div className="output-pane">
            {isLoadingPyodide && !pyodide && <div className="loading-overlay">Loading Python Environment...</div>}
            <OutputTerminal output={output} onClear={handleClear} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
