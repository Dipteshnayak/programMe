import React from 'react';
import { Play, Share2, Sun, Maximize2 } from 'lucide-react';
import './Navbar.css';

interface NavbarProps {
    onRun: () => void;
    isRunning: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ onRun, isRunning }) => {
    return (
        <header className="navbar">
            <div className="navbar-left">
                <span className="file-name">main.py</span>
            </div>

            <div className="navbar-right">
                <button className="icon-btn" title="Fullscreen">
                    <Maximize2 size={18} />
                </button>
                <button className="icon-btn" title="Toggle Theme">
                    <Sun size={18} />
                </button>
                <button className="share-btn">
                    <Share2 size={16} style={{ marginRight: '6px' }} />
                    Share
                </button>
                <button className="run-btn" onClick={onRun} disabled={isRunning}>
                    {isRunning ? 'Running...' : (
                        <>
                            Run <Play size={16} style={{ marginLeft: '6px' }} fill="white" />
                        </>
                    )}
                </button>
            </div>
        </header>
    );
};

export default Navbar;
