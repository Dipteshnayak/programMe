import React from 'react';
import { FileCode2, Database, Globe, Coffee, Box } from 'lucide-react';
import './Sidebar.css';

const Sidebar: React.FC = () => {
    return (
        <aside className="sidebar">
            <div className="sidebar-logo">
                <div className="logo-box">P</div>
            </div>

            <div className="sidebar-menu">
                <SidebarItem icon={<FileCode2 size={24} />} label="Python" active />
                <SidebarItem icon={<Globe size={24} />} label="Web" />
                <SidebarItem icon={<Database size={24} />} label="SQL" />
                <SidebarItem icon={<Coffee size={24} />} label="Java" />
                <SidebarItem icon={<Box size={24} />} label="Other" />
            </div>
        </aside>
    );
};

interface SidebarItemProps {
    icon: React.ReactNode;
    label: string;
    active?: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, active }) => {
    return (
        <div className={`sidebar-item ${active ? 'active' : ''}`} title={active ? 'Active' : ''}>
            {icon}
        </div>
    );
};

export default Sidebar;
